% SRCFUN Apply function to each filenames of a ScatNet-compatible src
%
% Usage
%   cell_out = SRCFUN(fun, src);

function cell_out = srcfun(fun, src)
	time_start = clock;
	for k = 1:length(src)
		db.indices{k} = k;
        %src.files{k}��һ��·�������˴�����Ϊ�µ�������󼴿�
		filename(:,:) = src(k,:,:);
		cell_out{k} = fun(filename);

		tm0 = tic;
		time_elapsed = etime(clock, time_start);
		estimated_time_left = time_elapsed * (length(src)-k) / k;
% 		fprintf('calculated features for %s. (%.2fs)\n',src{k},toc(tm0));
		fprintf('%d / %d : estimated time left %d seconds\n',k,length(src),floor(estimated_time_left));		
    end
end






%     for i = 1:length(H_data)
%         variablename1 = [y'num2str(i)'];
%         variablename1 = H_data(i,:);
%         variablename2 = [x'num2str(i)'];
%         variablename2 = reshape(variablename1,32,80);
%     end