clear;clc;
figure('color','white');hold on;box on
true=linspace(1,0,55);
plot(true,'k','LineWidth',2)
%���Լ�����
load('wavelet_weighting');
test_output1 = test_output;
plot(test_output1,'-ro','LineWidth',2)
hold on;
%��MAE
mae = zeros(1,3);
mae(1) = mean(abs(test_output - true'));
%��MAE
rmse = zeros(1,3);
rmse(1) = sqrt(mean((test_output - true').^2));
%�޼�Ȩ
hold on;
load('noweighting');
test_output2 = test_output;
plot(test_output2,'-ys','LineWidth',2);
mae(2) = mean(abs(test_output2 - true'));
rmse(2) = sqrt(mean((test_output2 - true').^2));
%�޼�Ȩ��С��
hold on;
load('baselineDANN');
plot(pred2,'-c+','LineWidth',2);
mae(3) = mean(abs(pred2 - true'));
rmse(3) = sqrt(mean((pred2 - true').^2));
%����Ȩ
hold on;
load('opposite_weighting');
test_output3 = test_output;
plot(test_output3,'-b*','LineWidth',2);
mae(4) = mean(abs(test_output3 - true'));
rmse(4) = sqrt(mean((test_output3 - true').^2));


k6=stem(-abs(true'-test_output1),'r');
k7=stem(-abs(true'-test_output2),'y');
k8=stem(-abs(true'-pred2),'c');
k9=stem(-abs(true'-test_output3),'b');

% xlim([0,length(true)])
% ylim([-0.6,max([true;test_output1;test_output])])
legend('Real','Wavelet and Weighting','NoWeighting','Baseline','OppositeWeighting')
ylabel('RUL & Error','FontSize',11,'FontWeight','bold')
xlabel('Sample Points','FontSize',11,'FontWeight','bold')
box on

