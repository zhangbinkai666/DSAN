clear;clc;
load('B1_1.mat');
load('H_data_RMS_1_6.mat');
A = trans_scatt_all(141:200);%60
% A = trans_scatt_all(142:200);%59
% A = trans_scatt_all(146:200);%55
% A = trans_scatt_all(105:200);%96
% A = trans_scatt_all(159:200);%42
% A = trans_scatt_all(155:200);%46
% A = trans_scatt_all(139:200);%62
% A = trans_scatt_all(152:200);%49
% A = trans_scatt_all(138:200);%63
% A = trans_scatt_all(175:200);%26

L = length(A);

%��Ƶ---�Ƕ�
for i=1:L
    for j =1:32
        %ȡ��8������ÿ�������ֵ
        expr = ['angel_' num2str(j)   '=A{1, i}{1, 2}.signal{1, j};' ];
        eval(expr);
        %���������д���һ������
        expr1 = ['m_feas_angel_' num2str(j)  '(i,:,:) = angel_' num2str(j)  ';' ];
        eval(expr1); 
    end 
end
%��Ƶ--�߶�--�Ƕ�
for i=1:L
    for m =1:384
        %ȡ��8������ÿ�������ֵ
        expr = ['angel_' num2str(m)   '=A{1, i}{1, 3}.signal{1, m};' ];
        eval(expr);
        %���������д���һ������
        expr1 = ['h_feas_angel_' num2str(m)  '(i,:,:) = angel_' num2str(m)  ';' ];
        eval(expr1);   
    end   
end

%reshape
for i =1:32
    expr2 = ['m_feas_angel_' num2str(i)  '= reshape(m_feas_angel_' num2str(i) ',L,40);'];
    eval(expr2);
end
for i =1:384
    expr2 = ['h_feas_angel_' num2str(i)  '= reshape(h_feas_angel_' num2str(i) ',L,40);'];
    eval(expr2);
end

%��ά--PCA
for j =1:32
    %ת��
    expr3 = sprintf("b = m_feas_angel_%s;", num2str(j),num2str(j));
    eval(expr3);
    b = b';
    %PCA
    expr4 = sprintf("pm_feas_%s = pca(b,'NumComponent',1);", num2str(j),num2str(j));
    eval(expr4);
end
for j =1:384
    %ת��
    expr3 = sprintf("b = h_feas_angel_%s;", num2str(j),num2str(j));
    eval(expr3);
    b = b';
    %PCA
    expr4 = sprintf("ph_feas_%s = pca(b,'NumComponent',1);", num2str(j),num2str(j));
    eval(expr4);
end


%��һ��
H_data_RMS_1 = mapminmax(H_data_RMS',0,1);
for j = 1:32
    expr3 = sprintf("b = pm_feas_%s;", num2str(j),num2str(j));
    eval(expr3);
    b = b';
    expr2 = ['m_feas_angel_' num2str(j)  '= mapminmax(b,0,1);'];
    eval(expr2);    
end
for j = 1:384
    expr3 = sprintf("b = ph_feas_%s;", num2str(j),num2str(j));
    eval(expr3);
    b = b';
    expr2 = ['h_feas_angel_' num2str(j)  '= mapminmax(b,0,1);'];
    eval(expr2);    
end


dif_result1 = zeros(1,32);
for j = 1:32
    %����DTWֵ
    expr5 = ['dif_' num2str(j)   '= dtw(m_feas_angel_' num2str(j) ',H_data_RMS_1);'];
    eval(expr5);
    %�洢������
    expr6 = ['dif_result1(' num2str(j)  ') = dif_' num2str(j) ';'];
    eval(expr6);    
end
dif_result2 = zeros(1,384);
for j = 1:384
    %����DTWֵ
    expr5 = ['dif_' num2str(j)   '= dtw(h_feas_angel_' num2str(j) ',H_data_RMS_1);'];
    eval(expr5);
    %�洢������
    expr6 = ['dif_result2(' num2str(j)  ') = dif_' num2str(j) ';'];
    eval(expr6);    
end

%�Ƚ�8�Ƕȼ������--����ͬ�Ƕ��µĺͽ��бȽ�
for i = 1:8
    expr = ['dif_sum_m_' num2str(i) '= 0;' ];
    eval(expr);
    for j =1:4
        a = (i+8*(j-1));
        expr = ['dif_sum_m_' num2str(i) '=dif_result1(' num2str(a) ')+dif_sum_m_' num2str(i) ';'];
        eval(expr);
    end
end
for i = 1:8
    expr = ['dif_sum_M_ (' num2str(i) ') =dif_sum_m_' num2str(i) ';'];
    eval(expr);
end

%�Ƚ�64�Ƕȼ������--����ͬ�Ƕ��µĺͽ��бȽ�
for i = 1:64
    expr = ['dif_sum_h_' num2str(i) '= 0;' ];
    eval(expr);
    for j =1:6
        a = (i+64*(j-1));
        expr = ['dif_sum_h_' num2str(i) '=dif_result2(' num2str(a) ')+dif_sum_h_' num2str(i) ';'];
        eval(expr);
    end
end
for i = 1:64
    expr = ['dif_sum_H_ (' num2str(i) ') =dif_sum_h_' num2str(i) ';'];
    eval(expr);
end
%����ȡ��Сֵ
[Y1,I1] = sort(dif_sum_M_);
[Y2,I2] = sort(dif_sum_H_);
Y11 = Y1(1);
Y21 = Y2(1);
for i = 1:8
    expr = ['dif_sum_M_(' num2str(i) ') = dif_sum_M_(' num2str(i) ')/Y11' ';'];
    eval(expr);
end
for i = 1:64
    expr = ['dif_sum_H_(' num2str(i) ') = dif_sum_H_(' num2str(i) ')/Y21' ';'];
    eval(expr);
end
[Ymbest_angle,Imbest_angle] = sort(dif_sum_M_);
[Yhbest_angle,Ihbest_angle] = sort(dif_sum_H_);
Imbest_angle(1)
Ihbest_angle(1)