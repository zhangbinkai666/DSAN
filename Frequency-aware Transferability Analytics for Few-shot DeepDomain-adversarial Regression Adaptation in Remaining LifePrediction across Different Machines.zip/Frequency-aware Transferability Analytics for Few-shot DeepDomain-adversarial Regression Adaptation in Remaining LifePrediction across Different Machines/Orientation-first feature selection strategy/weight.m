clear;clc;
%B1-1
L = 200;
for i = 1:7
    expr = ['E:\Code_true\DANN\caculate weight\B1_' num2str(i) '.mat'];
    load(expr);
    %ȡ��7����е����������ں�
    L_feas(:,:,i) = l_feas;
    M_feas(:,:,i) = m_feas;
    H_feas(:,:,i) = h_feas;
end 

L_feas= reshape(L_feas,L,40*7);
M_feas= reshape(M_feas,L,160*7);
H_feas= reshape(H_feas,L,240*7);

%��ά--PCA
p_L_feas = pca(L_feas','NumComponent',1);
p_M_feas = pca(M_feas','NumComponent',1);
p_H_feas = pca(H_feas','NumComponent',1);
%��һ��
L_feas= mapminmax(p_L_feas',0,1);
M_feas= mapminmax(p_M_feas',0,1);
H_feas= mapminmax(p_H_feas',0,1);

%B2-1
load('E:\Code_true\DANN\caculate weight\B2_1.mat')
%��ά--PCA
T_p_l_feas = pca(l_feas','NumComponent',1);
T_p_m_feas = pca(m_feas','NumComponent',1);
T_p_h_feas = pca(h_feas','NumComponent',1);
%��һ��
Test_l_feas= mapminmax(T_p_l_feas',0,1);
Test_m_feas= mapminmax(T_p_m_feas',0,1);
Test_h_feas= mapminmax(T_p_h_feas',0,1);

%DTW
dif_result1 = dtw(L_feas,Test_l_feas);
dif_result2 = dtw(M_feas,Test_m_feas);
dif_result3 = dtw(H_feas,Test_h_feas);
sum = dif_result1+dif_result2+dif_result3;

l1_weight = sum/dif_result1;
h1_weight = sum/dif_result2;
m1_weight = sum/dif_result3;

sum1 = l1_weight+h1_weight+m1_weight;
W_L = l1_weight/sum1
W_M = m1_weight/sum1
W_H = h1_weight/sum1


