%����ͼ
clear;clc;
load('epoch.mat');
target_loss = reshape(target_loss,14,100);
boxplot(target_loss)
