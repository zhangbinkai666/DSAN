# -*- coding: utf-8 -*-

import os
from pyexpat import model

import torch
import math
import torch.nn as nn
import torch.optim as optim
import numpy as np
import argparse
import torch.nn.functional as F
from torch.autograd import Function
from util.dataNorm import datanorm
from AE_DANN import Extractor,Regression,Dann_l,Dann_m,Dann_h, Regression111
import scipy.io as sci
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
import tensorly as tl
tl.set_backend('pytorch')
import time
import scipy.io as sio
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler 
#%%数据加载
t = 8

data_path = "/home/htu/workspace/zbk/DANN/UNSW/data/"

X1L = sci.loadmat(data_path+'B1_1_feature.mat')['l_feas'][:]#[-59:,:]
X1M = sci.loadmat(data_path+'B1_1_feature.mat')['m_feas'][:]#[-59:,:]
X1H = sci.loadmat(data_path+'B1_1_feature.mat')['h_feas'][:]#[-59:,:]

X2L = sci.loadmat(data_path+'B1_2_feature.mat')['l_feas'][:]#[-59:,:]
X2M = sci.loadmat(data_path+'B1_2_feature.mat')['m_feas'][:]#[-59:,:]
X2H = sci.loadmat(data_path+'B1_2_feature.mat')['h_feas'][:]#[-59:,:]

X3L = sci.loadmat(data_path+'B1_3_feature.mat')['l_feas'][:]#[-55:,:]
X3M = sci.loadmat(data_path+'B1_3_feature.mat')['m_feas'][:]#[-55:,:]
X3H = sci.loadmat(data_path+'B1_3_feature.mat')['h_feas'][:]#[-55:,:]

X4L =sci.loadmat(data_path+'Select_WAV_U1.mat')['l_feas'][:]#[-49:,:]
X4M =sci.loadmat(data_path+'Select_WAV_U1.mat')['m_feas'][:]#[-49:,:]
X4H =sci.loadmat(data_path+'Select_WAV_U1.mat')['h_feas'][:]#[-49:,:]

X5L =sio.loadmat(data_path+'Select_WAV_U2.mat')['l_feas'][:]#[-26:,:]
X5M =sio.loadmat(data_path+'Select_WAV_U2.mat')['m_feas'][:]#[-26:,:]
X5H =sio.loadmat(data_path+'Select_WAV_U2.mat')['h_feas'][:]#[-26:,:]

#归一化
#2)实例化一个转换器类
transfer=MinMaxScaler(feature_range=[0,1])   #rang范围可改变
#3)调用transform转换 
for i in range(1,10):
    locals()[f'X{i}L_new']=transfer.fit_transform(locals()[f'X{i}L'])
    locals()[f'X{i}M_new']=transfer.fit_transform(locals()[f'X{i}M'])
    locals()[f'X{i}H_new']=transfer.fit_transform(locals()[f'X{i}H'])

#源域
dataSL=[X1L_new,X2L_new,X3L_new]
dataSM=[X1M_new,X2M_new,X3M_new]
dataSH=[X1H_new,X2H_new,X3H_new]
#目标域
dataVL=[X4L_new]
dataVM=[X4M_new]
dataVH=[X4H_new]
#测试
dataTL=[X5L_new]
dataTM=[X5M_new]
dataTH=[X5H_new]


#导入权重
w = sci.loadmat('/home/htu/workspace/zbk/DANN/UNSW/data/weight.mat')
W_L = w.get('W_L')
W_M = w.get('W_M')
W_H = w.get('W_H')
#转换为tensor
def create_RMS(dataX):  
    return torch.tensor(dataX).float()

#将源域，目标域和测试数据转换为tensor
dataTrainS_list_all = [[],[],[]]  
dataTrainT_list_all = [[],[],[]]  
dataTrainV_list_all = [[],[],[]]  
#源域低中高tensor
for i in range(len(dataSL)):
    dataTrainS_list_all[0].append(create_RMS(dataSL[i]))
for i in range(len(dataSM)):
    dataTrainS_list_all[1].append(create_RMS(dataSM[i]))  
for i in range(len(dataSH)):
    dataTrainS_list_all[2].append(create_RMS(dataSH[i]))

#目标域低中高tensor
for i in range(len(dataVL)):
    dataTrainV_list_all[0].append(create_RMS(dataVL[i]))
for i in range(len(dataVM)):
    dataTrainV_list_all[1].append(create_RMS(dataVM[i]))  
for i in range(len(dataVH)):
    dataTrainV_list_all[2].append(create_RMS(dataVH[i]))

#测试低中高tensor
for i in range(len(dataTL)):
    dataTrainT_list_all[0].append(create_RMS(dataTL[i]))
for i in range(len(dataTM)):
    dataTrainT_list_all[1].append(create_RMS(dataTM[i]))  
for i in range(len(dataTH)):
    dataTrainT_list_all[2].append(create_RMS(dataTH[i]))


#构建数据成LSTM形式
def create_data_sample(dataX, time_step):   
    X = []
    for i in range(dataX.shape[0]-time_step):
        X.append(dataX[i:i+time_step])  
    return X

#构建RUL标签
def create_data_label(dataX, time_step): 
    y = np.linspace(1,0,len(dataX)-time_step)
    return (torch.tensor(y).float())

#生成源域目标域测试集的RUL标签值
dataTrainS_list_label = []                    
dataTrainT_list_label = [] 
dataTrainV_list_label = [] 
for i in range(len(dataSL)):
    dataTrainS_list_label.append(create_data_label(dataSL[i],t))  
for i in range(len(dataTL)):
    dataTrainT_list_label.append(create_data_label(dataTL[i],t))
for i in range(len(dataVL)):
    dataTrainV_list_label.append(create_data_label(dataVL[i],t))


#%% 模型参数
input_size_L = 40
input_size_M = 160
input_size_H = 240

hidden_size = 100 #该维度指的是lstm的特征输出维度，进入fc+relu
num_layers = 3
dropout = 0.5 

cuda =torch.cuda.is_available()
if cuda:
    device='cuda'
else:
    device='cpu'


model_domain1 = Dann_l(input_size_L, hidden_size, num_layers, dropout).to(device)
model_domain2 = Dann_m(input_size_M, hidden_size, num_layers, dropout).to(device)
model_domain3 = Dann_h(input_size_H, hidden_size, num_layers, dropout).to(device)

model1 = Regression().to(device)
# model2 = Regression().to(device)

optimizer = optim.Adam([{'params':model_domain1.parameters(),'lr':0.01},
                        {'params':model_domain2.parameters(),'lr':0.01},
                        {'params':model_domain3.parameters(),'lr':0.01},
                        {'params':model1.parameters(),'lr':0.01}])

criterion1 = nn.MSELoss()
criterion2 = nn.CrossEntropyLoss()

#%%  模型的测试部分！！！！！！！！
out_list1 = [1]
target_loss = []
target_L_loss=[]
target_M_loss=[]
target_H_loss=[]
def test():
    with torch.no_grad():  

        dataL, targetL = dataTrainT_list_all[0][0],dataTrainT_list_label[0]
        dataM, targetM = dataTrainT_list_all[1][0],dataTrainT_list_label[0]
        dataH, targetH = dataTrainT_list_all[2][0],dataTrainT_list_label[0]
        target = dataTrainT_list_label[0]

        targetL = targetL.float().to(device)
        targetM = targetM.float().to(device)
        targetH = targetH.float().to(device)

        dataL = dataL.float().to(device)
        dataM = dataM.float().to(device)
        dataH = dataH.float().to(device)

        #相空间重构
        fea_t_L = create_data_sample(dataL,t)
        fea_t_M = create_data_sample(dataM,t)
        fea_t_H = create_data_sample(dataH,t)

        fea_test_L = torch.stack(fea_t_L, dim=0)
        fea_test_M = torch.stack(fea_t_M, dim=0)
        fea_test_H = torch.stack(fea_t_H, dim=0)

        #提取的公共特征
        feadt_L,_=model_domain1(fea_test_L,alpha)
        feadt_M,_=model_domain2(fea_test_M,alpha)
        feadt_H,_=model_domain3(fea_test_H,alpha)

        feadtt_L= feadt_L.float().to(device)
        feadtt_M= feadt_M.float().to(device)
        feadtt_H= feadt_H.float().to(device)

        #方案一---直接维度融合
        # feadttt = torch.zeros(55,192)
        # feadttt = torch.cat([feadtt_L,feadtt_M],dim=1)
        # feadttt = torch.cat([feadttt,feadtt_H],dim=1)
        #方案二---按照权重相加
        # feadttt = torch.zeros(55,64)
        # feadttt =   0.33*feadtt_L+ +0.33*feadtt_M +0.33*feadtt_M
        # feadttt =   0.98*feadtt_L+ +0.015*feadtt_M +0.005*feadtt_M
        feadttt = W_L[0][0]*feadtt_L + W_M[0][0]*feadtt_M + W_H[0][0]*feadtt_H 

        # feadttt = 0.01*feadtt_L + 0.55*feadtt_M + 0.44*feadtt_H   
        feadttt= feadttt.float().to(device)

        #test_output预测结果
        test_output = model1(feadttt)

        test_loss = float(criterion1(test_output.view(-1,1), target.view(-1,1).to(device)))

        target_loss.append(test_loss)  ##预测损失   

        print("轮数：{} 测试的损失为：{}".format(epoch+1,test_loss))

        return test_output,feadttt
        # test_output_L = model1(feadtt_L)
        # test_output_M = model1(feadtt_M)
        # test_output_H = model1(feadtt_H)

        # test_loss_L = float(criterion1(test_output_L.view(-1,1), targetL.view(-1,1)))
        # test_loss_M = float(criterion1(test_output_M.view(-1,1), targetM.view(-1,1)))
        # test_loss_H = float(criterion1(test_output_H.view(-1,1), targetH.view(-1,1)))
        
        # target_L_loss.append(test_loss_L)  ##预测损失   
        # target_M_loss.append(test_loss_M)  ##预测损失   
        # target_H_loss.append(test_loss_H)  ##预测损失   

        # sio.savemat('pred161.mat',{'pred1':test_output_L})
        # sio.savemat('pred162.mat',{'pred2':test_output_M})
        # sio.savemat('pred163.mat',{'pred3':test_output_H})

    # print("低频的测试的损失为：{}".format(test_loss_L))
    # print("中频的测试的损失为：{}".format(test_loss_M))
    # print("高频的测试的损失为：{}".format(test_loss_H))

    # return test_output_L,test_output_M,test_output_H



#%%模型的训练部分
start_time = time.time()
allepoch = 200    #800
loss_list = []
# loss_list_0 = []
# loss_list_1 = []
# loss_list_2 = []
# loss_list_3 = []
# loss_list_4 = []
# loss_list_5 = []
# loss_list_6 = []
# loss_list_7 = []
# loss_list_8 = []
# loss_list_9 = []
# loss_list_10 = []
# loss_list_11 = []
# loss_list_12 = []
# loss_list_13 = []

# loss_list_all = [[],[],[],[],[],[],[],[],[],[]]
for epoch in range(allepoch):
    
    p = float(epoch) / allepoch
    alpha = 2. / (1. + np.exp(-10. * p)) - 1
    
    #初始化损失
    lossdc = torch.zeros(1).to(device)
    
    bef_dcsL=[]
    bef_dcsM=[]
    bef_dcsH=[]

    bef_dctL=[]
    bef_dctM=[]
    bef_dctH=[]

    aft_dcsL=[]
    aft_dcsM=[]
    aft_dcsH=[]

    aft_dctL=[]
    aft_dctM=[]
    aft_dctH=[]
    loss_sum = 0

    for batch_idx in range(14):
        optimizer.zero_grad()
        err_t_label2=torch.zeros(1).to(device)
        ssi = batch_idx%(len(dataTrainS_list_all[0]))
        tsi = batch_idx%(len(dataTrainV_list_all[0]))
        #读低频
        data_sourceL = dataTrainS_list_all[0][ssi]
        data_targetL = dataTrainV_list_all[0][tsi]
        #读中频
        data_sourceM = dataTrainS_list_all[1][ssi]
        data_targetM = dataTrainV_list_all[1][tsi]
        #读高频
        data_sourceH = dataTrainS_list_all[2][ssi]
        data_targetH = dataTrainV_list_all[2][tsi]

        bef_dcsL.append(data_sourceL)
        bef_dcsM.append(data_sourceM)
        bef_dcsH.append(data_sourceH)

        bef_dctL.append(data_targetL)
        bef_dctM.append(data_targetM)
        bef_dctH.append(data_targetH)

        #低频进lstm
        Xs_L = create_data_sample(data_sourceL,t)
        Xt_L = create_data_sample(data_targetL,t)
        Xs_L=torch.stack(Xs_L, dim=0)         
        Xt_L=torch.stack(Xt_L, dim=0)  

        #中频进lstm
        Xs_M = create_data_sample(data_sourceM,t)
        Xt_M = create_data_sample(data_targetM,t)
        Xs_M=torch.stack(Xs_M, dim=0)         
        Xt_M=torch.stack(Xt_M, dim=0)  

        #高频进lstm
        Xs_H = create_data_sample(data_sourceH,t)
        Xt_H = create_data_sample(data_targetH,t)
        Xs_H=torch.stack(Xs_H, dim=0)         
        Xt_H=torch.stack(Xt_H, dim=0) 

        #低频源域数据和目标域数据对抗
        combined_image_L = torch.cat((Xs_L, Xt_L), 0) 
        combined_image_L = combined_image_L.float().to(device)
        fea_domain_L,domain_pred_L =  model_domain1(combined_image_L,alpha)
        
        domain_source_labels = torch.zeros(Xs_L.shape[0]).type(torch.LongTensor)
        domain_target_labels = torch.ones(Xt_L.shape[0]).type(torch.LongTensor)
        domain_combined_label = torch.cat((domain_source_labels, domain_target_labels), 0)

        dcL = criterion2(domain_pred_L, domain_combined_label.to(device))

        hn1_L = fea_domain_L[:len(Xs_L)].float().to(device)
        hn2_L = fea_domain_L[len(Xs_L):].float().to(device) 

        #中频源域数据和目标域数据对抗
        combined_image_M = torch.cat((Xs_M, Xt_M), 0) 
        combined_image_M = combined_image_M.float().to(device)
        fea_domain_M,domain_pred_M =  model_domain2(combined_image_M,alpha)
        
        domain_source_labels = torch.zeros(Xs_M.shape[0]).type(torch.LongTensor)
        domain_target_labels = torch.ones(Xt_M.shape[0]).type(torch.LongTensor)
        domain_combined_label = torch.cat((domain_source_labels, domain_target_labels), 0)

        dcM = criterion2(domain_pred_M, domain_combined_label.to(device))

        hn1_M = fea_domain_M[:len(Xs_M)].float().to(device)
        hn2_M = fea_domain_M[len(Xs_M):].float().to(device) 

        #高频源域数据和目标域数据对抗
        combined_image_H = torch.cat((Xs_H, Xt_H), 0) 
        combined_image_H = combined_image_H.float().to(device)
        fea_domain_H,domain_pred_H =  model_domain3(combined_image_H,alpha)
        
        domain_source_labels = torch.zeros(Xs_H.shape[0]).type(torch.LongTensor)
        domain_target_labels = torch.ones(Xt_H.shape[0]).type(torch.LongTensor)
        domain_combined_label = torch.cat((domain_source_labels, domain_target_labels), 0)

        dcH = criterion2(domain_pred_H, domain_combined_label.to(device))

        hn1_H = fea_domain_H[:len(Xs_H)].float().to(device)
        hn2_H = fea_domain_H[len(Xs_H):].float().to(device) 

        aft_dcsL.append(hn1_L)
        aft_dcsM.append(hn1_M)
        aft_dcsH.append(hn1_H)

        aft_dctL.append(hn2_L)
        aft_dctM.append(hn2_M)
        aft_dctH.append(hn2_H)

        sio.savemat('/home/htu/workspace/zbk/DANN/fea/feas_Train_%s.mat'%(epoch),{'feaS_L':hn1_L.cpu().detach().numpy(),'feaT_L':hn2_L.cpu().detach().numpy(),'feaS_M':hn1_M.cpu().detach().numpy(),'feaT_M':hn2_M.cpu().detach().numpy(),'feaS_H':hn1_H.cpu().detach().numpy(),'feaT_H':hn2_H.cpu().detach().numpy(),}) 
        
        #回归器的训练
        #源域
        # s_img = torch.zeros(52,192)
        # s_img = torch.cat([hn1_L,hn1_M],dim=1)
        # s_img = torch.cat([s_img,hn1_H],dim=1)
        s_img = torch.zeros(52,64)
        s_img = W_L[0][0]*hn1_L + W_M[0][0]*hn1_M + W_H[0][0]*hn1_H  
        # s_img = 0.98*hn1_L + 0.015*hn1_M + 0.005*hn1_H    
        s_img= s_img.float().to(device)

        s_label = dataTrainS_list_label[ssi]
        s_img= s_img.float().to(device)   
        s_label = s_label.float().to(device).view(-1,1) 
        aa = model1(s_img)
        ly = criterion1(aa.view(-1,1) , s_label.to(device))  

        #目标域
        # t_img = torch.zeros(41,192)
        # t_img = torch.cat([hn2_L,hn2_M],dim=1)
        # t_img = torch.cat([t_img,hn2_H],dim=1)
        t_img = torch.zeros(41,64)
        t_img = W_L[0][0]*hn2_L + W_M[0][0]*hn2_M + W_H[0][0]*hn2_H   
        # t_img = 0.98*hn2_L + 0.015*hn2_M + 0.005*hn2_H   
        t_img= t_img.float().to(device)

        t_label = dataTrainV_list_label[tsi]
        t_img= t_img.float().to(device)   
        t_label = t_label.float().to(device).view(-1,1) 
        aat = model1(t_img)
        Vly = criterion1(aat.view(-1,1) , t_label.to(device))  

        # dc_loss = 0.98*dcL + 0.015*dcM + 0.005*dcH #  0.1*dcL +0.1*dcM + 0.8*dcH  #0.45*dcL + 0.11*dcM + 0.11*dcH   #   W_M[0][0]*dcM + W_H[0][0]*dcH 
        dc_loss = W_L[0][0]*dcL + W_M[0][0]*dcM + W_H[0][0]*dcH
        
        # pre_loss = lyL + VlyL + lyM + VlyM + lyH +VlyH
        pre_loss = ly+ Vly

        err_all = dc_loss + pre_loss
        err_all.backward()
        optimizer.step()
        loss_sum = loss_sum + err_all
    loss = loss_sum/14
    loss_list.append(loss.cpu().detach().numpy())
    #     if batch_idx == 0:
    #         loss_list_0.append(err_all.cpu().detach().numpy())
    #     elif batch_idx == 1:
    #         loss_list_1.append(err_all.cpu().detach().numpy())
    #     elif batch_idx == 2:
    #         loss_list_2.append(err_all.cpu().detach().numpy())
    #     elif batch_idx == 3:
    #         loss_list_3.append(err_all.cpu().detach().numpy())
    #     elif batch_idx == 4:
    #         loss_list_4.append(err_all.cpu().detach().numpy())
    #     elif batch_idx == 5:
    #         loss_list_5.append(err_all.cpu().detach().numpy())
    #     elif batch_idx == 6:
    #         loss_list_6.append(err_all.cpu().detach().numpy())
    #     elif batch_idx == 7:
    #         loss_list_7.append(err_all.cpu().detach().numpy())
    #     elif batch_idx == 8:
    #         loss_list_8.append(err_all.cpu().detach().numpy())
    #     elif batch_idx == 9:
    #         loss_list_9.append(err_all.cpu().detach().numpy())
    #     elif batch_idx == 10:
    #         loss_list_10.append(err_all.cpu().detach().numpy())
    #     elif batch_idx == 11:
    #         loss_list_11.append(err_all.cpu().detach().numpy())
    #     elif batch_idx == 12:
    #         loss_list_12.append(err_all.cpu().detach().numpy())
    #     else:
    #         loss_list_13.append(err_all.cpu().detach().numpy())  
    # loss_list = np.vstack([np.array(loss_list_0),np.array(loss_list_1),np.array(loss_list_2),np.array(loss_list_3),np.array(loss_list_4),np.array(loss_list_5),np.array(loss_list_6),np.array(loss_list_7),np.array(loss_list_8),np.array(loss_list_9),np.array(loss_list_10),np.array(loss_list_11),np.array(loss_list_12),np.array(loss_list_13)])          
    #保存训练特征
    if (epoch+1)%100 == 0:#allepoch:
        #对抗前低特征
        bef_pfeaL11=bef_dcsL[0].detach().numpy()
        bef_pfeaL12=bef_dcsL[1].detach().numpy()
        bef_pfeaL13=bef_dcsL[2].detach().numpy()
        bef_pfeaL14=bef_dcsL[3].detach().numpy()
        bef_pfeaL15=bef_dcsL[4].detach().numpy()
        bef_pfeaL16=bef_dcsL[5].detach().numpy()
        bef_pfeaL17=bef_dcsL[6].detach().numpy()
        bef_pfeaL21=bef_dctL[0].detach().numpy()
        bef_pfeaL26=bef_dctL[1].detach().numpy()
        #对抗前中特征
        bef_pfeaM11=bef_dcsM[0].detach().numpy()
        bef_pfeaM12=bef_dcsM[1].detach().numpy()
        bef_pfeaM13=bef_dcsM[2].detach().numpy()
        bef_pfeaM14=bef_dcsM[3].detach().numpy()
        bef_pfeaM15=bef_dcsM[4].detach().numpy()
        bef_pfeaM16=bef_dcsM[5].detach().numpy()
        bef_pfeaM17=bef_dcsM[6].detach().numpy()
        bef_pfeaM21=bef_dctM[0].detach().numpy()
        bef_pfeaM26=bef_dctM[1].detach().numpy()
        #对抗前高特征
        bef_pfeaH11=bef_dcsH[0].detach().numpy()
        bef_pfeaH12=bef_dcsH[1].detach().numpy()
        bef_pfeaH13=bef_dcsH[2].detach().numpy()
        bef_pfeaH14=bef_dcsH[3].detach().numpy()
        bef_pfeaH15=bef_dcsH[4].detach().numpy()
        bef_pfeaH16=bef_dcsH[5].detach().numpy()
        bef_pfeaH17=bef_dcsH[6].detach().numpy()
        bef_pfeaH21=bef_dctH[0].detach().numpy()
        bef_pfeaH26=bef_dctH[1].detach().numpy()
        
        #对抗后低中高特征
        aft_pfeaL11=aft_dcsL[0].detach().cpu().numpy()
        aft_pfeaL12=aft_dcsL[1].detach().cpu().numpy()
        aft_pfeaL13=aft_dcsL[2].detach().cpu().numpy()
        aft_pfeaL14=aft_dcsL[3].detach().cpu().numpy()
        aft_pfeaL15=aft_dcsL[4].detach().cpu().numpy()
        aft_pfeaL16=aft_dcsL[5].detach().cpu().numpy()
        aft_pfeaL17=aft_dcsL[6].detach().cpu().numpy()
        aft_pfeaL21=aft_dctL[0].detach().cpu().numpy()
        aft_pfeaL26=aft_dctL[1].detach().cpu().numpy()

        aft_pfeaM11=aft_dcsM[0].detach().cpu().numpy()
        aft_pfeaM12=aft_dcsM[1].detach().cpu().numpy()
        aft_pfeaM13=aft_dcsM[2].detach().cpu().numpy()
        aft_pfeaM14=aft_dcsM[3].detach().cpu().numpy()
        aft_pfeaM15=aft_dcsM[4].detach().cpu().numpy()
        aft_pfeaM16=aft_dcsM[5].detach().cpu().numpy()
        aft_pfeaM17=aft_dcsM[6].detach().cpu().numpy()
        aft_pfeaM21=aft_dctM[0].detach().cpu().numpy()
        aft_pfeaM26=aft_dctM[1].detach().cpu().numpy()

        aft_pfeaH11=aft_dcsH[0].detach().cpu().numpy()
        aft_pfeaH12=aft_dcsH[1].detach().cpu().numpy()
        aft_pfeaH13=aft_dcsH[2].detach().cpu().numpy()
        aft_pfeaH14=aft_dcsH[3].detach().cpu().numpy()
        aft_pfeaH15=aft_dcsH[4].detach().cpu().numpy()
        aft_pfeaH16=aft_dcsH[5].detach().cpu().numpy()
        aft_pfeaH17=aft_dcsH[6].detach().cpu().numpy()
        aft_pfeaH21=aft_dctH[0].detach().cpu().numpy()
        aft_pfeaH26=aft_dctH[1].detach().cpu().numpy()
        sio.savemat("/home/htu/workspace/zbk/DANN/wavelet_fea_bef_aft/epoch{}_fea.mat".format(epoch),{'bef_pfeaL11':bef_pfeaL11,'bef_pfeaL12':bef_pfeaL12,'bef_pfeaL13':bef_pfeaL13,
                                                                    'bef_pfeaL14':bef_pfeaL14,'bef_pfeaL15':bef_pfeaL15,'bef_pfeaL16':bef_pfeaL16,
                                                                    'bef_pfeaL17':bef_pfeaL17,'bef_pfeaL21':bef_pfeaL21,'bef_pfeaL26':bef_pfeaL26,
                                                                    'bef_pfeaM11':bef_pfeaM11,'bef_pfeaM12':bef_pfeaM12,'bef_pfeaM13':bef_pfeaM13,
                                                                    'bef_pfeaM14':bef_pfeaM14,'bef_pfeaM15':bef_pfeaM15,'bef_pfeaM16':bef_pfeaM16,
                                                                    'bef_pfeaM17':bef_pfeaM17,'bef_pfeaM21':bef_pfeaM21,'bef_pfeaM26':bef_pfeaM26,
                                                                    'bef_pfeaH11':bef_pfeaH11,'bef_pfeaH12':bef_pfeaH12,'bef_pfeaH13':bef_pfeaH13,
                                                                    'bef_pfeaH14':bef_pfeaH14,'bef_pfeaH15':bef_pfeaH15,'bef_pfeaH16':bef_pfeaH16,
                                                                    'bef_pfeaH17':bef_pfeaH17,'bef_pfeaH21':bef_pfeaH21,'bef_pfeaH26':bef_pfeaH26,
                                                                    'aft_pfeaL11':aft_pfeaL11,'aft_pfeaL12':aft_pfeaL12,'aft_pfeaL13':aft_pfeaL13,
                                                                    'aft_pfeaL14':aft_pfeaL14,'aft_pfeaL15':aft_pfeaL15,'aft_pfeaL16':aft_pfeaL16,
                                                                    'aft_pfeaL17':aft_pfeaL17,'aft_pfeaL21':aft_pfeaL21,'aft_pfeaL26':aft_pfeaL26,
                                                                    'aft_pfeaM11':aft_pfeaM11,'aft_pfeaM12':aft_pfeaM12,'aft_pfeaM13':aft_pfeaM13,
                                                                    'aft_pfeaM14':aft_pfeaM14,'aft_pfeaM15':aft_pfeaM15,'aft_pfeaM16':aft_pfeaM16,
                                                                    'aft_pfeaM17':aft_pfeaM17,'aft_pfeaM21':aft_pfeaM21,'aft_pfeaM26':aft_pfeaM26,
                                                                    'aft_pfeaH11':aft_pfeaH11,'aft_pfeaH12':aft_pfeaH12,'aft_pfeaH13':aft_pfeaH13,
                                                                    'aft_pfeaH14':aft_pfeaH14,'aft_pfeaH15':aft_pfeaH15,'aft_pfeaH16':aft_pfeaH16,
                                                                    'aft_pfeaH17':aft_pfeaH17,'aft_pfeaH21':aft_pfeaH21,'aft_pfeaH26':aft_pfeaH26})           
        



        test_output,fea =test()
        sio.savemat("/home/htu/workspace/zbk/DANN/result_ronghe/epoch{}_result.mat".format(epoch),{'test_output':test_output.cpu().detach().numpy(),'fea':fea.cpu().detach().numpy()})



    # if ((epoch+1)%10) == 0:
    #     loss_list_all.append(loss_list.detach().numpy()) 
    
# sio.savemat("/home/htu/workspace/zbk/DANN/result_ronghe/epoch{}_result.mat".format(epoch),{'test_output':test_output.cpu().detach().numpy(),'fea':fea.cpu().detach().numpy()})
sio.savemat('/home/htu/workspace/zbk/DANN/result_ronghe/loss.mat',{'target_loss':loss_list})
