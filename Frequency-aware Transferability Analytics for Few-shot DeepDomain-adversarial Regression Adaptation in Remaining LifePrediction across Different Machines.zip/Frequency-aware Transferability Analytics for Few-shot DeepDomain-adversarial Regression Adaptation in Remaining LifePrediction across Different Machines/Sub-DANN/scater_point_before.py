# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # 空间三维画图
import seaborn as sns
import scipy.io as sio 
from sklearn.decomposition import PCA
from sklearn import preprocessing
# from util.dataNorm import datanorm
#%%2D
path='/home/htu/workspace/zbk/DANN/wavelet_fea_bef_aft/epoch199_fea.mat'
# 源域
# 低频
cho11L=sio.loadmat(path)['bef_pfeaL11']
cho12L=sio.loadmat(path)['bef_pfeaL12']
cho13L=sio.loadmat(path)['bef_pfeaL13']
cho14L=sio.loadmat(path)['bef_pfeaL14']
cho15L=sio.loadmat(path)['bef_pfeaL15']
cho16L=sio.loadmat(path)['bef_pfeaL16']
cho17L=sio.loadmat(path)['bef_pfeaL17']
# 中频
cho11M=sio.loadmat(path)['bef_pfeaM11']
cho12M=sio.loadmat(path)['bef_pfeaM12']
cho13M=sio.loadmat(path)['bef_pfeaM13']
cho14M=sio.loadmat(path)['bef_pfeaM14']
cho15M=sio.loadmat(path)['bef_pfeaM15']
cho16M=sio.loadmat(path)['bef_pfeaM16']
cho17M=sio.loadmat(path)['bef_pfeaM17']
# 高频
cho11H=sio.loadmat(path)['bef_pfeaH11']
cho12H=sio.loadmat(path)['bef_pfeaH12']
cho13H=sio.loadmat(path)['bef_pfeaH13']
cho14H=sio.loadmat(path)['bef_pfeaH14']
cho15H=sio.loadmat(path)['bef_pfeaH15']
cho16H=sio.loadmat(path)['bef_pfeaH16']
cho17H=sio.loadmat(path)['bef_pfeaH17']

# 目标域
# 低频
cho21L=sio.loadmat(path)['bef_pfeaL21']
cho26L=sio.loadmat(path)['bef_pfeaL26']
# 中频
cho21M=sio.loadmat(path)['bef_pfeaM21']
cho26M=sio.loadmat(path)['bef_pfeaM26']
# 高频
cho21H=sio.loadmat(path)['bef_pfeaH21']
cho26H=sio.loadmat(path)['bef_pfeaH26']


L=np.vstack((cho11L,cho12L,cho13L,cho14L,cho15L,cho16L,cho17L,cho21L,cho26L))
M=np.vstack((cho11M,cho12M,cho13M,cho14M,cho15M,cho16M,cho17M,cho21M,cho26M))
H=np.vstack((cho11H,cho12H,cho13H,cho14H,cho15H,cho16H,cho17H,cho21H,cho26H))

dataL = L
dataM = M
dataH = H

pca = PCA(n_components=2)

pca.fit(dataL)
PL = pca.transform(dataL)

pca.fit(dataM)
PM = pca.transform(dataM)

pca.fit(dataH)
PH = pca.transform(dataH)

PL = preprocessing.MinMaxScaler().fit_transform(PL)
PM = preprocessing.MinMaxScaler().fit_transform(PM)
PH = preprocessing.MinMaxScaler().fit_transform(PH)

##低频
#源域
dataxL1=PL[:495,0]
datayL1=PL[:495,1]
#目标域
dataxL2=PL[421:495,0]
datayL2=PL[421:495,1]

##中频
#源域
dataxM1=PM[:495,0]
datayM1=PM[:495,1]
#目标域
dataxM2=PM[421:495,0]
datayM2=PM[421:495,1]

##高频
#源域
dataxH1=PH[:495,0]
datayH1=PH[:495,1]
#目标域
dataxH2=PH[421:495,0]
datayH2=PH[421:495,1]

# 绘制散点图
plt.figure(figsize=[9,8])
s1=plt.scatter(dataxL1, datayL1, c='b',marker='s')
s2=plt.scatter(dataxL2, datayL2, c='y',marker='s')
s3=plt.scatter(dataxM1, datayM1, c='g')
s4=plt.scatter(dataxM2, datayM2, c='r')
s5=plt.scatter(dataxH1, datayH1, c='c',marker='^')
s6=plt.scatter(dataxH2, datayH2, c='m',marker='^')

plt.xlabel('PCA1')
 
plt.ylabel('PCA2')
 
# plt.title("Before Transfer Learning Decomposition")

plt.legend((s1,s2,s3,s4,s5,s6),('Source low-frequency','Target low-frequency','Source middle-frequency','Target middle-frequency','Source high-frequency','Target high-frequency') ,loc = 'best')
plt.show()
plt.savefig('/home/htu/workspace/zbk/DANN/result/scatterpoint_before')
